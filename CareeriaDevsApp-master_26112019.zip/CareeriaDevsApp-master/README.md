# CareeriaDevsApp
Syksy2019 SCRUM projekti
Visual Studio 2019 16.3.4
Bootstrap 4.3.1
JQuery 3.4.1
Popper 1.14.3

Muutostesti 21.10.2019 by Ari Leskinen